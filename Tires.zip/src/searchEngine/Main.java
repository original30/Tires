package searchEngine;

import java.io.IOException;

public class Main {
	
	public static void search(String word) throws IOException {
		ReadPage read = new ReadPage();
		read.store();
		Trie trie = new Trie();
		for(int i=0; i<read.list.size(); i++) {
			char n = (char)(i+1 + '0');
			for(int j=0; j<read.list.get(i).length; j++) {
				trie.insert(read.list.get(i)[j], n);
			}
		}
		trie.len = read.list.size();
		if(trie.search(word)) {
			for(int i=0; i<trie.cur.size(); i++) {
				int a = trie.cur.get(i) - '0';
				String value = read.map.get(a);
				System.out.println(word + " -> " + value);
			}
		}else {
			System.out.println(word + " -> not found");
		}
		trie.cur.clear();
	}
	
	
	public static void main(String[] args) throws IOException {
		//test
		search("populations");
		search("game");
		search("world");
		search("google");
		search("stack");
	}

}
