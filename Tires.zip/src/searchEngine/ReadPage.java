package searchEngine;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class ReadPage {
	
	public HashMap<Integer, String> map = new HashMap<>();
	public ArrayList<String[]> list = new ArrayList<>();
	
	public String[] read(String url) throws IOException {
		// read url and store the words into array
		Document doc = Jsoup.connect(url).get();
        String text = doc.text();
        text = text.replaceAll("[^0-9a-zA-Z ]", "");
        text = text.toLowerCase();
        String[] word = text.split(" ");
        return word;
	}
	
	
	public void store() throws IOException {
		ArrayList<String> array = new ArrayList<>();
		BufferedReader reader;
		// read url file and put the url and words array into map
		try {
			reader = new BufferedReader(new FileReader("/Users/yby/eclipse-workspace/searchEngine/file.txt"));
			String line = reader.readLine();
			while (line != null) {
				array.add(line);
				line = reader.readLine();
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		for(int i=0; i<array.size(); i++) {
			list.add(read(array.get(i)));
			map.put(i+1, array.get(i));
		}
	}
	
}
