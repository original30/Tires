package searchEngine;

import java.util.ArrayList;
import java.util.HashMap;

public class Trie {
	
	public int len;
	public ArrayList<Character> cur = new ArrayList<>();
	ReadPage read = new ReadPage();
	
	// initialize trie structure using hashmap
	class TrieNode {
		
		private char character;
		private TrieNode parent;
		private HashMap<Character, TrieNode> children = new HashMap<Character, TrieNode>();
		private boolean leaf;

		public TrieNode() {}
		
		public TrieNode(char character) {
			this.character = character;
		}
		
		public void setParent(TrieNode parent) {
			this.parent = parent;
		}
		
		public TrieNode getParent() {
			return parent;
		}
		
		public HashMap<Character, TrieNode> getChildren() {
			return children;
		}
		
		public boolean isLeaf() {
			return leaf;
		}
		
		public void setLeaf(boolean leaf) {
			this.leaf = leaf;
		}
	}
	
	private TrieNode root;
	
	// set default root and parent
	public Trie() {
		root = new TrieNode();
		root.setParent(new TrieNode());
	}
	
	// inserting a word	
	public void insert(String word, char index) {
		HashMap<Character, TrieNode> nextChar = root.getChildren();
		TrieNode p = root;
		for(int i = 0; i < word.length(); i++) {			
			char c = word.charAt(i);
			TrieNode curNode = null;
			// locate and add the character
			if(nextChar.containsKey(c)) {
				curNode = nextChar.get(c);
			} else {		
				curNode = new TrieNode(c);
				nextChar.put(c, curNode);
				curNode.setParent(p);
			}
			p = curNode;
			nextChar = curNode.getChildren();
			// last character from word
			if(i == word.length()-1) {
				curNode.setLeaf(true);
				// put list index of website at bottom
				if(!nextChar.containsKey(index)) {
					curNode = new TrieNode(index);
					nextChar.put(index, curNode);
					curNode.setParent(p);
				}
			}
		}
	}
	
	
	public boolean search(String word) {
		HashMap<Character, TrieNode> nextChar = root.getChildren();
		TrieNode curNode = null;
		for(int i = 0; i < word.length(); i++) {
			char c = word.charAt(i);
			if(nextChar.containsKey(c)) {
				curNode = nextChar.get(c);
				nextChar = curNode.getChildren();				
			} else {
				return false;				
			}
		}
		
		// output if node is leaf
		if(curNode != null && curNode.isLeaf()) {
			for(int i=1; i<len+1; i++) {
				char n = (char)(i + '0');
				if(nextChar.containsKey(n)) {
					cur.add(n);
				}
			}
			return true;
		}
		return false;
	}

}
